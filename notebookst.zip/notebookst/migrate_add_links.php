<?php
/**
 * Migración: Agregar columna 'link' a materias y tareas
 * Ejecutar una sola vez en: http://localhost/notebookst/migrate_add_links.php
 */

require_once 'model/conexion.php';

try {
    // Verificar si la columna ya existe en materias
    $checkMateria = $pdo->query("SHOW COLUMNS FROM materias LIKE 'link'");
    if ($checkMateria->rowCount() == 0) {
        $pdo->exec("ALTER TABLE materias ADD COLUMN link VARCHAR(500) DEFAULT NULL AFTER color");
        echo "<p style='color:green;'>✓ Columna 'link' agregada a tabla 'materias'</p>";
    } else {
        echo "<p style='color:orange;'>⚠ La columna 'link' ya existe en 'materias'</p>";
    }

    // Verificar si la columna ya existe en tareas
    $checkTarea = $pdo->query("SHOW COLUMNS FROM tareas LIKE 'link'");
    if ($checkTarea->rowCount() == 0) {
        $pdo->exec("ALTER TABLE tareas ADD COLUMN link VARCHAR(500) DEFAULT NULL AFTER estado");
        echo "<p style='color:green;'>✓ Columna 'link' agregada a tabla 'tareas'</p>";
    } else {
        echo "<p style='color:orange;'>⚠ La columna 'link' ya existe en 'tareas'</p>";
    }

    echo "<p style='color:blue;'><strong>Migración completada exitosamente.</strong></p>";
    echo "<p><a href='index.php'>Volver al inicio</a></p>";

} catch (PDOException $e) {
    echo "<p style='color:red;'><strong>Error en la migración:</strong> " . htmlspecialchars($e->getMessage()) . "</p>";
}
?>
